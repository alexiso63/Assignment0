<html>
    <head>
        <title>Alexis's Restaurant Tax Calculator</title>
    </head>
    <body>
       <h1>Alexis's Restaurant Tax Calculator</h1> 
       
       <p style="color:red;">This app will allow the customer to calculate
       the tax of the restaurant depending on which state 
       you are in and how much percentage you want to tip</p>
       
       <img src="pictures/restaurant1.jpg">
        
        
        
        
        
        
    </body>
</html>